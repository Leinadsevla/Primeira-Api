require('dotenv').config();
const express = require('express');
const { Pool } = require('pg');
const taskRoutes = require('./routes/taskRoutes');

const app = express();
app.use(express.json());

// Configuração  pool de conexão com PostgreSQL
const pool = new Pool({
  user: process.env.DB_USER,
  host: process.env.DB_HOST,
  database: process.env.DB_NAME,
  password: process.env.DB_PASSWORD,
  port: process.env.DB_PORT,
  ssl: process.env.DB_SSL === 'true' ? { rejectUnauthorized: false } : false,  // Configuração de SSL 
  endpoint_id: process.env.DB_ENDPOINT_ID  // Acresenta o endpoint_id a configuração
});

app.locals.pool = pool;

app.use('/api', taskRoutes);

// inicia o servidor
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
