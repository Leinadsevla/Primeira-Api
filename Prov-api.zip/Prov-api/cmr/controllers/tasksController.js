const { Pool } = require('pg');

// Função para listar  os registros
const getItems = async (req, res) => {
  try {
    const result = await req.app.locals.pool.query('SELECT * FROM tarefas');
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// Função para adicionar um novo registro
const createItem = async (req, res) => {
  const { titulo, descricao, status, usuario_id } = req.body;
  try {
    if (!titulo || !status) {
      return res.status(400).json({ message: 'Os Campos são obrigatórios não podem ser nulos' });
    }
    const result = await req.app.locals.pool.query(
      'INSERT INTO tarefas (titulo, descricao, status, usuario_id) VALUES ($1, $2, $3, $4) RETURNING *',
      [titulo, descricao, status, usuario_id]
    );
    res.status(201).json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};


// Função de buscar para um registro específico
const getItemById = async (req, res) => {
  const { id } = req.params;
  try {
    const result = await req.app.locals.pool.query('SELECT * FROM tarefas WHERE id = $1', [id]);
    if (result.rows.length === 0) {
      return res.status(404).json({ message: 'Registro não localizado' });
    }
    res.json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};


// Função que deleta um registro
const deleteItem = async (req, res) => {
  const { id } = req.params;
  try {
    const result = await req.app.locals.pool.query('DELETE FROM tarefas WHERE id = $1 RETURNING *', [id]);
    if (result.rows.length === 0) {
      return res.status(404).json({ message: 'Registro não localizado' });
    }
    res.status(204).send();
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// Função para atualizar um registro
const updateItem = async (req, res) => {
  const { id } = req.params;
  const { titulo, descricao, status } = req.body;
  try {
    const result = await req.app.locals.pool.query(
      'UPDATE tarefas SET titulo = $1, descricao = $2, status = $3 WHERE id = $4 RETURNING *',
      [titulo, descricao, status, id]
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ message: 'Registro não localizado' });
    }
    res.json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// Função para Filtrar tarefas por status
const getTarefasFilter = async (req, res) => {
  const { status } = req.query;
  try {
    if (!status) {
      return res.status(400).json({ error: "O parâmetro 'status' é obrigatório." });
    }
    const result = await req.app.locals.pool.query(
      'SELECT * FROM tarefas WHERE status = $1',
      [status]
    );
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};



module.exports = {
  getItems,
  getItemById,
  createItem,
  updateItem,
  deleteItem,
  getTarefasFilter,
};
